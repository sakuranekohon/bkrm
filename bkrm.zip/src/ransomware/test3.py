from mysocket import MySocket

s = MySocket.Server()

s.startTCPserver2()